/**
 * Support package for beans-style handling of Java 5 annotations.
 */
package org.springframework.beans.annotation;
